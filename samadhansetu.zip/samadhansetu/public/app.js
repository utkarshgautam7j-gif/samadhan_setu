const S = ['Reported','Under Review','Verified','Assigned','Team Formed','Proposal Submitted','Prototype','Testing','Pilot','Completed'];
const $ = s => document.querySelector(s);
let token = localStorage.getItem('st_token'), me = JSON.parse(localStorage.getItem('st_user') || 'null'), probs = [], tab = '';
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = n => '₹' + Number(n || 0).toLocaleString('en-IN');
const when = d => new Date(d).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
const idx = p => S.indexOf(p.status);

async function api(path, body) {
  const r = await fetch('/api' + path, { method: body ? 'POST' : 'GET', headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const d = await r.json(); if (!r.ok) { if (r.status === 401 && token) logout(true); throw new Error(d.error || 'Something went wrong'); } return d;
}
function toast(m, err) { const t = $('#toast'); t.textContent = m; t.className = 'toast' + (err ? ' err' : ''); t.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(() => t.hidden = true, 2800); }
function logout(silent) { token = null; me = null; localStorage.clear(); if (!silent) toast('Logged out'); location.hash = ''; route(); }

// ---------- Layout ----------
const LOGO = '<svg viewBox="0 0 24 24" fill="none" stroke="#E8A317" stroke-width="2.4" stroke-linecap="round"><path d="M2 16c4-9 16-9 20 0M2 19h20M7 12v7M12 10v9M17 12v7"/></svg>';
function nav() {
  $('#nav').innerHTML = `<div class="logo" onclick="location.hash='';route()"><i>${LOGO}</i>SamadhanSetu</div>
  <a class="hide" onclick="location.hash='';route();setTimeout(()=>document.getElementById('how')?.scrollIntoView({behavior:'smooth'}),50)">How it works</a>
  <a class="hide" onclick="location.hash='';route();setTimeout(()=>document.getElementById('feed')?.scrollIntoView({behavior:'smooth'}),50)">Problems</a>
  ${me ? `<a onclick="location.hash='app';route()">Dashboard</a><div class="who"><b>${esc(me.name)}</b>${esc(me.role)}</div><button class="btn ghost sm" onclick="logout()">Log out</button>` : `<button class="btn sm" onclick="location.hash='login';route()">Log in</button>`}`;
}
function route() { nav(); window.scrollTo(0, 0); const h = location.hash.slice(1); if (h === 'login' && !me) return loginView(); if (h === 'app' || h === 'login') return me ? appView() : loginView(); home(); }

// ---------- Public website ----------
const card = p => `<div class="card prob" data-open="${p.id}"><span class="chip">${esc(p.category)}</span><span class="chip ${p.severity === 'High' ? 'hi' : 'me'}">${esc(p.severity)}</span><h3>${esc(p.title)}</h3><small>${esc(p.location)}${p.supporters?.length ? ' · ' + p.supporters.length + ' facing this too' : ''}</small>
  <div style="margin-top:10px"><span class="chip ${p.status === 'Completed' ? 'ok' : p.status === 'Rejected' ? 'no' : 'st'}">${esc(p.status)}</span></div><div class="bar"><i style="width:${Math.max(idx(p), 0) / 9 * 100}%"></i></div></div>`;

async function home() {
  const [st, list] = await Promise.all([api('/public/stats'), api('/public/problems')]);
  const hs = S.map((s, i) => `<div class="step ${i <= 6 ? 'on' : ''} ${i === 6 ? 'now' : ''}" style="animation-delay:${i * 130}ms"><b></b>${s}</div>`).join('');
  $('#view').innerHTML = `<section class="hero"><div class="hero-in"><div><h1>From local problems to real solutions</h1>
    <p>Citizens report what is broken. Government verifies it. Student teams build the fix. Industry funds and pilots it. Everyone can watch it get solved.</p>
    <div class="row"><button class="btn alt" onclick="location.hash='login';route()">Report a problem</button><button class="btn ghost" style="color:#fff;border-color:#4A6378" onclick="location.hash='login';route()">Partner with us</button></div></div>
    <div class="bridge"><h3>One problem, tracked end to end</h3><h4>Potholes on Ranchi-Hatia main road</h4>${hs}</div></div></section>
  <div class="stats"><div class="stat"><b>${st.reported}</b><span>Problems reported</span></div><div class="stat"><b>${st.verified}</b><span>Verified by government</span></div><div class="stat"><b>${st.inProgress}</b><span>Being solved by student teams</span></div><div class="stat"><b>${money(st.funding)}</b><span>Pledged by industry</span></div></div>
  <div class="wrap"><h2 class="sec" id="how">How it works</h2><p class="sub">Four steps take a complaint from a phone to a pilot project.</p>
  <div class="flow"><div><em>Step 1</em><h3>Report</h3><p>Describe the problem, add a photo and pin the location. AI checks for duplicates.</p></div><div><em>Step 2</em><h3>Verify</h3><p>Government moderators confirm it is real and route it to the right university.</p></div><div><em>Step 3</em><h3>Build</h3><p>A student team with a faculty mentor submits a proposal and builds a prototype.</p></div><div><em>Step 4</em><h3>Support and track</h3><p>Industry funds, mentors and pilots. Citizens follow every milestone.</p></div></div>
  <h2 class="sec">Built for three groups</h2><p class="sub">Everyone works on the same workflow.</p>
  <div class="roles"><div class="card"><h3>Citizens</h3><p>Report in under a minute and see exactly where your problem stands.</p></div><div class="card"><h3>Universities</h3><p>Adopt real challenges, form teams and build solutions with a mentor.</p></div><div class="card"><h3>Industry</h3><p>Fund, mentor or provide equipment and see the impact you create.</p></div></div>
  <h2 class="sec" id="feed">Verified problems</h2><p class="sub">Open any problem to see its full journey.</p><div class="grid">${list.map(card).join('')}</div></div><footer>SamadhanSetu · SIH26043 · Government of Jharkhand</footer>`;
}

// ---------- Login ----------
function loginView() {
  const D = [['citizen@demo.com', 'Citizen'], ['admin@demo.com', 'Govt Admin'], ['uni@demo.com', 'University'], ['industry@demo.com', 'Industry']];
  $('#view').innerHTML = `<div class="card login"><h2>Log in to SamadhanSetu</h2><form class="form" id="lf"><label>Email<input name="email" type="email" required></label><label>Password<input name="password" type="password" required></label><button class="btn">Log in</button></form>
  <p class="sub" style="margin-top:18px;margin-bottom:0">Demo accounts (password: demo123)</p><div class="demo">${D.map(d => `<button class="btn ghost sm" data-demo="${d[0]}">${d[1]}</button>`).join('')}</div></div>`;
  const go = async (email, password) => { try { const r = await api('/login', { email, password }); token = r.token; me = r.user; localStorage.setItem('st_token', token); localStorage.setItem('st_user', JSON.stringify(me)); tab = ''; location.hash = 'app'; route(); toast('Welcome, ' + me.name); } catch (e) { toast(e.message, true); } };
  $('#lf').onsubmit = e => { e.preventDefault(); go(e.target.email.value, e.target.password.value); };
  document.querySelectorAll('[data-demo]').forEach(b => b.onclick = () => go(b.dataset.demo, 'demo123'));
}

// ---------- Dashboard ----------
const TABS = { citizen: [['report', 'Report a problem'], ['mine', 'My reports'], ['feed', 'Problem feed']], admin: [['queue', 'Review queue'], ['all', 'All problems'], ['analytics', 'Analytics'], ['logs', 'Audit log']], university: [['open', 'Open challenges'], ['mine', 'Our projects']], industry: [['back', 'Proposals to back'], ['funded', 'Our support']] };
const FILTER = { citizen: { mine: p => p.reporter === me.id, feed: p => idx(p) >= 2 }, admin: { queue: p => p.status === 'Reported' || p.status === 'Under Review', all: () => true }, university: { open: p => p.status === 'Verified', mine: p => p.assignedTo === me.org }, industry: { back: p => idx(p) >= 5, funded: p => p.offers.some(o => o.by === me.org) } };
const HEAD = { report: 'Tell us what needs fixing', mine: 'Your reports', feed: 'Verified problems near you', queue: 'Waiting for your review', all: 'Every problem on the platform', open: 'Challenges ready to adopt', back: 'Projects that need support', funded: 'Projects you support' };

async function appView() {
  tab = tab || TABS[me.role][0][0];
  $('#view').innerHTML = `<div class="wrap"><h2 style="font-size:26px">${esc(me.name)}</h2><div class="tabs">${TABS[me.role].map(t => `<button class="tab ${t[0] === tab ? 'on' : ''}" data-tab="${t[0]}">${t[1]}</button>`).join('')}</div><div id="pane"></div></div>`;
  document.querySelectorAll('[data-tab]').forEach(b => b.onclick = () => { tab = b.dataset.tab; appView(); });
  const pane = $('#pane');
  try {
    if (tab === 'report') return reportForm(pane);
    if (tab === 'analytics') return analytics(pane);
    if (tab === 'logs') return logs(pane);
    probs = await api('/problems');
    const list = probs.filter(FILTER[me.role][tab]);
    pane.innerHTML = `<h3 style="margin-bottom:14px">${HEAD[tab]}</h3>` + (list.length ? `<div class="grid">${list.map(card).join('')}</div>` : '<div class="empty">Nothing here yet. New items will show up as the workflow moves.</div>');
  } catch (e) { toast(e.message, true); }
}

function reportForm(pane) {
  let photo = null;
  pane.innerHTML = `<form class="form" id="rf"><label>Title<input name="title" required placeholder="e.g. Broken streetlights on market road"></label>
  <label>What is happening?<textarea name="description" rows="4" required placeholder="Describe the problem and who it affects"></textarea></label>
  <div class="two"><label>Location<input name="location" required placeholder="Area, city"></label><label>Severity<select name="severity"><option>Low</option><option selected>Medium</option><option>High</option></select></label></div>
  <div class="two"><label>Category (AI fills this in)<select name="category"><option value="">Let AI decide</option>${['Roads', 'Water', 'Electricity', 'Health', 'Agriculture', 'Education', 'Sanitation', 'Other'].map(c => `<option>${c}</option>`).join('')}</select></label><label>Photo<input type="file" name="photo" accept="image/*" capture="environment"></label></div>
  <button type="button" class="btn ghost sm" id="gps" style="justify-self:start">Use my GPS location</button><div class="ai" id="ai" hidden></div><button class="btn" style="justify-self:start">Submit report</button></form>`;
  const f = $('#rf'); let t;
  const check = () => { clearTimeout(t); t = setTimeout(async () => { if (f.title.value.length + f.description.value.length < 12) return; const a = await api('/ai/analyze', { title: f.title.value, description: f.description.value }), box = $('#ai'); box.hidden = false; box.className = 'ai' + (a.duplicates.length ? ' warn' : '');
    box.innerHTML = `<b>AI check:</b> looks like a <b>${a.category}</b> issue, routed to ${esc(a.university)}.` + (a.duplicates.length ? `<br>Possible duplicate: ${a.duplicates.map(d => `${esc(d.title)} (${d.score}% similar)`).join(', ')}. You can still submit, and we will link them.` : ' No duplicates found.'); }, 500); };
  f.title.oninput = f.description.oninput = check;
  $('#gps').onclick = () => navigator.geolocation?.getCurrentPosition(p => { f.location.value = p.coords.latitude.toFixed(4) + ', ' + p.coords.longitude.toFixed(4); toast('Location captured'); }, () => toast('Could not read GPS. Type the location instead.', true));
  f.photo.onchange = e => { const file = e.target.files[0]; if (!file) return; const img = new Image(); img.onload = () => { const c = document.createElement('canvas'), k = Math.min(1, 800 / img.width); c.width = img.width * k; c.height = img.height * k; c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); photo = c.toDataURL('image/jpeg', .7); }; img.src = URL.createObjectURL(file); };
  f.onsubmit = async e => { e.preventDefault(); try { await api('/problems', { title: f.title.value, description: f.description.value, location: f.location.value, severity: f.severity.value, category: f.category.value, photo }); toast('Report submitted. You can track it under My reports.'); tab = 'mine'; appView(); } catch (er) { toast(er.message, true); } };
}

async function analytics(pane) {
  const a = await api('/analytics'), bars = (rows) => { const m = Math.max(1, ...rows.map(r => r.value)); return `<div class="bars">${rows.map(r => `<div><span>${esc(r.label)}</span><i style="width:${r.value / m * 100}%"></i><b>${r.value}</b></div>`).join('')}</div>`; };
  pane.innerHTML = `<div class="stats" style="margin:0 0 20px;padding:0"><div class="stat"><b>${a.total}</b><span>Total problems</span></div><div class="stat"><b>${a.pending}</b><span>Waiting for review</span></div><div class="stat"><b>${money(a.funding)}</b><span>Industry funding</span></div><div class="stat"><b>${a.byStatus[9].value}</b><span>Solved</span></div></div>
  <div class="two"><div class="card"><h3>By status</h3>${bars(a.byStatus)}</div><div class="card"><h3>By category</h3>${bars(a.byCategory)}</div></div>`;
}
async function logs(pane) { const l = await api('/logs'); pane.innerHTML = `<table><tr><th>Time</th><th>Who</th><th>Action</th><th>Problem</th></tr>${l.map(x => `<tr><td>${when(x.at)}</td><td>${esc(x.actor)}</td><td>${esc(x.action)}</td><td>${esc(x.ref)}</td></tr>`).join('')}</table>`; }

// ---------- Problem detail ----------
function actionsHTML(p) {
  const i = idx(p), mine = p.assignedTo === me.org, r = me.role;
  const input = (n, l, ph = '', t = 'text') => `<label>${l}<input name="${n}" type="${t}" placeholder="${ph}"></label>`;
  if (r === 'admin' && (p.status === 'Reported' || p.status === 'Under Review')) return `<div class="act-group">${input('note', 'Note (optional)')}<div class="row" style="margin-top:10px">${p.status === 'Reported' ? '<button class="btn ghost sm" data-act="review">Mark under review</button>' : ''}<button class="btn sm" data-act="verify">Verify and route to ${esc(p.university)}</button><button class="btn bad sm" data-act="reject">Reject as fake</button></div></div>`;
  if (r === 'university') {
    if (p.status === 'Verified') return `<div class="ai">AI match score for ${esc(me.org)}: <b>${me.org === p.university ? '92%' : '64%'}</b></div><button class="btn" data-act="accept">Accept this challenge</button>`;
    if (p.status === 'Assigned' && mine) return `<div class="act-group"><h4>Form your team</h4>${input('name', 'Team name')}${input('members', 'Student members', 'Names, comma separated')}${input('mentor', 'Faculty mentor')}<button class="btn" data-act="team">Create team</button></div>`;
    if (p.status === 'Team Formed' && mine) return `<div class="act-group"><h4>Submit your proposal</h4><label>Proposed solution<textarea name="solution" rows="3"></textarea></label><div class="two">${input('cost', 'Estimated cost (₹)', '', 'number')}${input('impact', 'Expected impact')}</div><button class="btn" data-act="proposal">Submit proposal</button></div>`;
    if (i >= 5 && i < 9 && mine) return `<div class="act-group">${input('note', 'Progress note')}<button class="btn" data-act="advance" style="margin-top:10px">Move to ${S[i + 1]}</button></div>`;
  }
  if (r === 'industry' && i >= 5) return `<div class="act-group"><h4>Support this project</h4><div class="two"><label>Type<select name="type"><option>Fund</option><option>Mentor</option><option>Equipment</option><option>Pilot</option></select></label>${input('amount', 'Amount (₹, if funding)', '', 'number')}</div>${input('detail', 'Details')}<button class="btn alt" data-act="offer" style="margin-top:10px">Offer support</button></div>`;
  if (r === 'citizen') {
    let h = ''; if (i >= 2 && !p.supporters.includes(me.id)) h += '<button class="btn ghost" data-act="support">I face this problem too</button>';
    if (p.status === 'Completed' && p.reporter === me.id && !p.rating) h += `<div class="act-group row"><select name="rating">${[5, 4, 3, 2, 1].map(n => `<option value="${n}">${n} stars</option>`).join('')}</select><button class="btn" data-act="rate">Rate the solution</button></div>`;
    return h;
  }
  return '';
}
function openProblem(id) {
  const p = probs.find(x => x.id === id); if (!p) return;
  const ci = idx(p), a = actionsHTML(p);
  $('#sheet').innerHTML = `<div class="row" style="justify-content:space-between"><div><span class="chip">${esc(p.category)}</span><span class="chip ${p.severity === 'High' ? 'hi' : 'me'}">${esc(p.severity)}</span><span class="chip ${p.status === 'Rejected' ? 'no' : 'st'}">${esc(p.status)}</span></div><button class="btn ghost sm" data-act="close">Close</button></div>
  <h2>${esc(p.title)}</h2><small style="color:var(--mute)">${esc(p.location)} · Reported by ${esc(p.reporterName)} · ${when(p.createdAt)} · ${p.supporters.length} facing this too</small>
  <p style="margin-top:12px">${esc(p.description)}</p>${p.photo ? `<img class="ph" src="${p.photo}" alt="Photo of the problem">` : ''}
  <div class="stepper">${S.map((s, i) => `<i class="${i < ci ? 'on' : i === ci ? 'now' : ''}" title="${s}"></i>`).join('')}</div>
  ${p.assignedTo ? `<div class="box"><h4>Solving university</h4>${esc(p.assignedTo)}</div>` : `<div class="box"><h4>Will be routed to</h4>${esc(p.university)}</div>`}
  ${p.team ? `<div class="box"><h4>Team ${esc(p.team.name)}</h4>Members: ${esc(p.team.members)}<br>Mentor: ${esc(p.team.mentor)}</div>` : ''}
  ${p.proposal ? `<div class="box"><h4>Proposal</h4>${esc(p.proposal.solution)}<br><b>Cost:</b> ${money(p.proposal.cost)} · <b>Impact:</b> ${esc(p.proposal.impact)}</div>` : ''}
  ${p.offers.length ? `<div class="box"><h4>Industry support</h4>${p.offers.map(o => `${esc(o.by)}: ${esc(o.type)}${o.amount ? ' ' + money(o.amount) : ''}, ${esc(o.detail)}`).join('<br>')}</div>` : ''}
  ${p.rating ? `<div class="box"><h4>Citizen rating</h4>${p.rating} out of 5</div>` : ''}
  <h4 style="margin-top:18px">Timeline</h4><div class="tl">${[...p.history].reverse().map(h => `<div><b>${esc(h.status)}</b> by ${esc(h.by)}${h.note ? ': ' + esc(h.note) : ''}<br><small>${when(h.at)}</small></div>`).join('')}</div>
  ${a ? `<div class="actions" data-pid="${p.id}">${a}</div>` : ''}`;
  $('#modal').hidden = false;
}
$('#modal').onclick = async e => {
  if (e.target.id === 'modal' || e.target.dataset.act === 'close') return $('#modal').hidden = true;
  const b = e.target.closest('[data-act]'), box = e.target.closest('[data-pid]'); if (!b || !box) return;
  const g = b.closest('.act-group') || b.parentElement, body = { action: b.dataset.act };
  g.querySelectorAll('input,select,textarea').forEach(x => body[x.name] = x.value);
  try { await api(`/problems/${box.dataset.pid}/action`, body); toast('Done'); probs = await api('/problems'); openProblem(box.dataset.pid); const pane = $('#pane'); if (pane) appView(); } catch (er) { toast(er.message, true); }
};
document.addEventListener('click', async e => { const c = e.target.closest('[data-open]'); if (!c) return; if (!me) { probs = await api('/public/problems'); return toast('Log in to see full details and take part'); } if (!probs.find(x => x.id === c.dataset.open)) probs = await api('/problems'); openProblem(c.dataset.open); });
window.onhashchange = route; route();
