// SamadhanSetu backend: plain Node.js, zero dependencies. Run: node server.js
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const PORT = process.env.PORT || 3000, DB = path.join(__dirname, 'data.json'), PUB = path.join(__dirname, 'public');
const STAGES = ['Reported','Under Review','Verified','Assigned','Team Formed','Proposal Submitted','Prototype','Testing','Pilot','Completed'];
const UNI = {Roads:'NIT Jamshedpur',Water:'IIT (ISM) Dhanbad',Electricity:'BIT Mesra',Health:'RIMS Ranchi',Agriculture:'Birsa Agricultural University',Education:'Ranchi University',Sanitation:'BIT Mesra',Other:'Ranchi University'};
const KW = {Roads:'road pothole bridge traffic highway footpath',Water:'water pipe tap drinking well flood drain',Electricity:'electric power light transformer outage pole',Health:'hospital health clinic doctor medicine ambulance',Agriculture:'farm crop farmer irrigation soil seed',Education:'school teacher student education classroom library',Sanitation:'garbage waste toilet sewage sanitation clean'};
const now = () => new Date().toISOString();
const uid = p => p + crypto.randomBytes(3).toString('hex');

// ---- "AI" service: keyword categorizer + Jaccard similarity duplicate finder ----
function categorize(t) { t = t.toLowerCase(); let best = 'Other', n = 0;
  for (const [k, v] of Object.entries(KW)) { const c = v.split(' ').filter(w => t.includes(w)).length; if (c > n) { n = c; best = k; } } return best; }
const toks = t => new Set(t.toLowerCase().match(/[a-z]{3,}/g) || []);
function sim(a, b) { const A = toks(a), B = toks(b); let i = 0; A.forEach(w => B.has(w) && i++); return A.size + B.size ? i / (A.size + B.size - i) : 0; }
function analyze(title, desc) { const text = title + ' ' + desc, category = categorize(text);
  const duplicates = db.problems.filter(p => p.status !== 'Rejected').map(p => ({ id: p.id, title: p.title, score: Math.round(sim(text, p.title + ' ' + p.description) * 100) }))
    .filter(d => d.score >= 30).sort((a, b) => b.score - a.score).slice(0, 3);
  return { category, university: UNI[category], duplicates }; }

// ---- Database (JSON file; swap for MongoDB later) ----
let db;
function seed() {
  const users = [
    { id:'u1', name:'Asha Kumari', email:'citizen@demo.com', role:'citizen' },
    { id:'u2', name:'Govt Admin, Jharkhand', email:'admin@demo.com', role:'admin' },
    { id:'u3', name:'Dr. R. Sinha', email:'uni@demo.com', role:'university', org:'NIT Jamshedpur' },
    { id:'u4', name:'Tata Steel Foundation', email:'industry@demo.com', role:'industry', org:'Tata Steel Foundation' }
  ].map(u => ({ ...u, password: 'demo123' }));
  const P = (title, description, category, location, severity, idx) => {
    const p = { id: uid('P'), title, description, category, location, severity, photo: null, reporter: 'u1', reporterName: 'Asha Kumari', supporters: [], university: UNI[category], assignedTo: null, team: null, proposal: null, offers: [], rating: null, createdAt: new Date(Date.now() - (idx + 2) * 1.5 * 864e5).toISOString(),
      history: STAGES.slice(0, idx + 1).map((s, i) => ({ status: s, by: i ? 'System' : 'Asha Kumari', at: new Date(Date.now() - (idx - i + 1) * 864e5).toISOString(), note: '' })), status: STAGES[idx] };
    if (idx >= 3) p.assignedTo = UNI[category];
    if (idx >= 4) p.team = { name: 'Team Setu-' + category.slice(0, 3), members: 'Rohan, Priya, Aman, Sneha', mentor: 'Prof. A. Mahto' };
    if (idx >= 5) p.proposal = { solution: 'Low-cost sensor + dashboard to detect and report the issue early, with a repair workflow for local bodies.', cost: 180000, impact: 'About 12,000 residents benefit' };
    if (idx >= 6) p.offers.push({ type: 'Fund', detail: 'Seed grant for prototype', amount: 150000, by: 'Tata Steel Foundation', at: now() });
    return p; };
  return { users, logs: [], problems: [
    P('Large potholes on Ranchi-Hatia main road', 'Deep potholes near the bridge cause daily accidents for two-wheelers, worse after rain.', 'Roads', 'Hatia, Ranchi', 'High', 6),
    P('No clean drinking water in Dumka village', 'The hand pump has been dry for months and the pipe supply is contaminated.', 'Water', 'Dumka', 'High', 4),
    P('Frequent power outage in Bokaro sector 4', 'Transformer overloads every evening, outage of 4 to 5 hours.', 'Electricity', 'Bokaro Steel City', 'Medium', 3),
    P('Garbage not collected near Jamshedpur market', 'Waste piles near the vegetable market, bad smell and mosquito risk.', 'Sanitation', 'Sakchi, Jamshedpur', 'Medium', 9),
    P('Primary school has no toilets for girls', 'The government school in Gumla has no working toilet, girls skip classes.', 'Education', 'Gumla', 'High', 2),
    P('Irrigation canal blocked, crops drying', 'Silt blocks the canal and farmers are losing paddy crop.', 'Agriculture', 'Hazaribagh', 'Medium', 0)
  ] }; }
if (fs.existsSync(DB)) db = JSON.parse(fs.readFileSync(DB, 'utf8')); else { db = seed(); }
const save = () => fs.writeFileSync(DB, JSON.stringify(db, null, 1)); save();

// ---- Helpers ----
const sessions = {};
const send = (res, c, d) => { res.writeHead(c, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(d)); };
const body = req => new Promise(r => { let b = ''; req.on('data', c => { b += c; if (b.length > 6e6) req.destroy(); }); req.on('end', () => { try { r(JSON.parse(b || '{}')); } catch { r({}); } }); });
const log = (u, action, ref) => db.logs.unshift({ at: now(), actor: u.name, role: u.role, action, ref });
const mv = (p, status, by, note = '') => { p.status = status; p.history.push({ status, by, at: now(), note }); };
const idx = p => STAGES.indexOf(p.status);
const visible = (u, p) => u.role === 'admin' || p.reporter === u.id || idx(p) >= 2;
const pub = p => ({ id: p.id, title: p.title, category: p.category, location: p.location, status: p.status, severity: p.severity, supporters: p.supporters.length });
const fail = (res, m, c = 400) => send(res, c, { error: m });

async function api(req, res, url) {
  const m = req.method, tok = (req.headers.authorization || '').slice(7), u = sessions[tok];
  const auth = () => { if (!u) { fail(res, 'Please log in first', 401); return null; } return u; };
  let r;
  if (m === 'POST' && url === '/api/login') { const b = await body(req);
    const f = db.users.find(x => x.email === b.email && x.password === b.password); if (!f) return fail(res, 'Wrong email or password', 401);
    const t = crypto.randomBytes(16).toString('hex'); sessions[t] = f; log(f, 'Logged in', ''); save();
    return send(res, 200, { token: t, user: { id: f.id, name: f.name, role: f.role, org: f.org } }); }
  if (m === 'GET' && url === '/api/me') return auth() && send(res, 200, { id: u.id, name: u.name, role: u.role, org: u.org });
  if (m === 'GET' && url === '/api/public/stats') { const n = db.problems.filter(p => idx(p) >= 2);
    return send(res, 200, { reported: db.problems.length, verified: n.length, inProgress: n.filter(p => idx(p) >= 3 && idx(p) < 9).length, solved: db.problems.filter(p => p.status === 'Completed').length,
      funding: db.problems.reduce((s, p) => s + p.offers.reduce((a, o) => a + (+o.amount || 0), 0), 0) }); }
  if (m === 'GET' && url === '/api/public/problems') return send(res, 200, db.problems.filter(p => idx(p) >= 2).map(pub));
  if (m === 'POST' && url === '/api/ai/analyze') { const b = await body(req); return send(res, 200, analyze(b.title || '', b.description || '')); }
  if (!auth()) return;
  if (m === 'GET' && url === '/api/problems') return send(res, 200, db.problems.filter(p => visible(u, p)).sort((a, b) => b.createdAt.localeCompare(a.createdAt)));
  if (m === 'POST' && url === '/api/problems') { if (u.role !== 'citizen') return fail(res, 'Only citizens can report problems', 403);
    const b = await body(req); if (!b.title || !b.description || !b.location) return fail(res, 'Title, description and location are required');
    const a = analyze(b.title, b.description), cat = b.category || a.category;
    const p = { id: uid('P'), title: b.title, description: b.description, category: cat, location: b.location, severity: b.severity || 'Medium', photo: b.photo || null, reporter: u.id, reporterName: u.name, supporters: [], university: UNI[cat], assignedTo: null, team: null, proposal: null, offers: [], rating: null, createdAt: now(), history: [], status: 'Reported', duplicateOf: a.duplicates[0]?.id || null };
    p.history.push({ status: 'Reported', by: u.name, at: now(), note: a.duplicates.length ? 'AI flagged a possible duplicate of ' + a.duplicates[0].id : 'AI categorized as ' + cat });
    db.problems.push(p); log(u, 'Reported problem', p.id); save(); return send(res, 200, p); }
  if (m === 'GET' && url === '/api/analytics') { if (u.role !== 'admin') return fail(res, 'Admins only', 403);
    const by = (f, keys) => keys.map(k => ({ label: k, value: db.problems.filter(p => f(p) === k).length }));
    return send(res, 200, { byStatus: by(p => p.status, STAGES), byCategory: by(p => p.category, Object.keys(UNI).filter(k => k !== 'Other').concat('Other')), total: db.problems.length,
      funding: db.problems.reduce((s, p) => s + p.offers.reduce((a, o) => a + (+o.amount || 0), 0), 0), pending: db.problems.filter(p => idx(p) <= 1 && idx(p) >= 0).length }); }
  if (m === 'GET' && url === '/api/logs') return u.role === 'admin' ? send(res, 200, db.logs.slice(0, 60)) : fail(res, 'Admins only', 403);
  if (m === 'POST' && (r = url.match(/^\/api\/problems\/(\w+)\/action$/))) {
    const p = db.problems.find(x => x.id === r[1]); if (!p) return fail(res, 'Problem not found', 404);
    const b = await body(req), a = b.action, i = idx(p), review = p.status === 'Reported' || p.status === 'Under Review', mine = p.assignedTo === u.org;
    if (u.role === 'admin' && review && a === 'review') mv(p, 'Under Review', u.name, b.note);
    else if (u.role === 'admin' && review && a === 'verify') { p.university = UNI[p.category]; mv(p, 'Verified', u.name, b.note || 'Verified and routed to ' + p.university); }
    else if (u.role === 'admin' && review && a === 'reject') mv(p, 'Rejected', u.name, b.note || 'Rejected as fake or invalid');
    else if (u.role === 'university' && p.status === 'Verified' && a === 'accept') { p.assignedTo = u.org; mv(p, 'Assigned', u.name, u.org + ' accepted the challenge'); }
    else if (u.role === 'university' && p.status === 'Assigned' && mine && a === 'team') { p.team = { name: b.name, members: b.members, mentor: b.mentor }; mv(p, 'Team Formed', u.name, 'Team ' + b.name + ' formed'); }
    else if (u.role === 'university' && p.status === 'Team Formed' && mine && a === 'proposal') { p.proposal = { solution: b.solution, cost: +b.cost || 0, impact: b.impact }; mv(p, 'Proposal Submitted', u.name, 'Proposal submitted'); }
    else if (u.role === 'university' && i >= 5 && i < 9 && mine && a === 'advance') mv(p, STAGES[i + 1], u.name, b.note);
    else if (u.role === 'industry' && i >= 5 && a === 'offer') { p.offers.push({ type: b.type, detail: b.detail, amount: +b.amount || 0, by: u.org, at: now() }); p.history.push({ status: p.status, by: u.org, at: now(), note: b.type + ' offered' }); }
    else if (u.role === 'citizen' && a === 'support') { if (!p.supporters.includes(u.id)) p.supporters.push(u.id); }
    else if (u.role === 'citizen' && p.status === 'Completed' && a === 'rate') p.rating = +b.rating;
    else return fail(res, 'This action is not allowed right now', 403);
    log(u, a + ' (' + p.status + ')', p.id); save(); return send(res, 200, p); }
  fail(res, 'Not found', 404);
}

const MIME = { '.html': 'text/html', '.css': 'text/css', '.js': 'text/javascript', '.svg': 'image/svg+xml' };
http.createServer(async (req, res) => {
  const url = req.url.split('?')[0];
  try {
    if (url.startsWith('/api/')) return await api(req, res, url);
    const f = path.join(PUB, url === '/' ? 'index.html' : url);
    if (!f.startsWith(PUB) || !fs.existsSync(f)) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' }); fs.createReadStream(f).pipe(res);
  } catch (e) { console.error(e); fail(res, 'Server error', 500); }
}).listen(PORT, () => console.log('SamadhanSetu running at http://localhost:' + PORT));
