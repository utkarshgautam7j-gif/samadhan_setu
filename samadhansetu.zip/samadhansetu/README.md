# SamadhanSetu - Demo Run Guide

## Chalane ke steps (VS Code)
1. Node.js install hona chahiye (https://nodejs.org, version 16 ya usse upar).
2. Folder ko VS Code me kholo: File > Open Folder > samadhansetu
3. Terminal kholo (Ctrl + `) aur likho:  node server.js
4. Browser me kholo: http://localhost:3000

Koi npm install nahi chahiye. Koi dependency nahi hai.

## Demo logins (password sabka: demo123)
- citizen@demo.com   -> Citizen (problem report karta hai)
- admin@demo.com     -> Govt Admin (verify / reject, analytics, audit log)
- uni@demo.com       -> University (challenge accept, team, proposal, progress)
- industry@demo.com  -> Industry (fund / mentor / equipment / pilot)

## Kal ka demo flow (5 min)
1. Home page dikhao: hero, stats, how it works, verified problems.
2. Citizen se login > "Report a problem" > title likho, AI category aur duplicate warning dikhao > Submit.
3. Admin se login > Review queue > problem Verify karo (university routing dikhegi).
4. University se login > Open challenges > Accept > Team banao > Proposal bhejo > stages aage badhao.
5. Industry se login > Proposals to back > Fund do.
6. Citizen se wapas login > problem kholo > timeline aur stepper dikhao.
7. Admin > Analytics aur Audit log dikhao.

## Reset karna ho to
data.json file delete karo aur server dobara chalao. Demo data wapas aa jayega.

## Structure
- server.js        : backend API, RBAC, AI categorize + duplicate detection, audit logs
- public/          : frontend (index.html, style.css, app.js)
- data.json        : database (pehli baar chalne par apne aap banti hai)

## Aage ke upgrades (blueprint ke hisaab se)
MongoDB + Mongoose, Express, React (Vite), Python FastAPI AI service, JWT refresh tokens,
Cloudinary/S3, offline PWA sync, multilingual support.
